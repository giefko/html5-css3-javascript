


<html>
<head>
  <meta charset="utf-8">
  <meta charset="utf-8">
		
  
  
  <link rel="stylesheet" href="css/style.css">

</head>

<header>

		<p align="left"><img  src="images/main.png" alt=""></p>
</header>
<body>

  <section class="container">
	
    <div class="login">
      <h1>Login Page</h1>
      <form action="login.php" name="myform" method="POST">
	  
		
		<?php echo "<font color='red'>Please check you username and password!</font>";  ?>
		
         <p><input type="text" name="user" placeholder="Username"></p>
         <p><input type="password" name="pass" placeholder="Password"></p>
       
         <p class="submit"><input type="submit" value="Login"></p>
       </form>
    </div>

    
  </section>

 
</body>


</html>
