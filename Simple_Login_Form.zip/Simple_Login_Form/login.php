<html>
	<head>
		<meta charset="utf-8">
		
		 <link rel="stylesheet" href="css/style.css">
	</head>
	<header>

		<p align="left"><img  src="images/main.png" alt=""></p>
</header>
<body>
<?php
	$username = $_POST['user'];
	$password = $_POST['pass'];
	include("db_connection.php");	
	
	$result=mysql_query("SELECT user,pass FROM login") or mysql_error();
	$num = mysql_num_rows($result);
	
	if($num>0)
		{
			while($row = mysql_fetch_array($result))
				{
				$hash = $row['pass'];
	
				if ((password_verify($password, $hash)) and $username == $row['user']) {
					
					mysql_close();
					header('Location: yourwelcomepage.php');
					
				}
				else { 
				
				
				
				
				
				header('Location: loginerror.php');
				
						}
				
				}}
				?>

</body>
</html>