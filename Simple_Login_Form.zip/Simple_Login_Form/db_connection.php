<?php
	// Connection to the DB
	$con = mysql_connect("localhost","root","");
	if (!$con){ die('Could not connect: ' . mysql_error()); }
	mysql_select_db("si_ste", $con);
	mysql_query("SET NAMES 'utf8'");
	mysql_query("SET CHARACTER SET 'utf8'");
?>