<!doctype html>
<?php session_start(); ?>
<html >

<head>
   <meta charset='utf-8'>
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   
   <link rel="stylesheet" href="cssmenu/styles.css">
 
   <script src="cssmenu/jquery-latest.min.js" type="text/javascript"></script>
   <script src="cssmenu/script.js"></script>
  
</head>

<body>

<p>
 <nav>
<div id='cssmenu'>
<ul>
   <li class='active'><a href='#'><span>Home</span></a></li>
   <li class='has-sub'><a href='#'><span>User</span></a>
      <ul>
         <li><a href= "" ><span>Register new user</span></a></li>
         <li><a href="" ><span>Delete User</span></a></li>
		 <li><a href= "" ><span>Edit users</span></a></li>
		 <li><a href= "" ><span>Search User</span></a></li>
         <li class='last'><a href="" ><span>Other page</span></a></li>
      </ul>
   </li>
   <li class='has-sub'><a href='#'><span>Other pages</span></a>
      <ul>
		 <li><a href="" ><span>Other page2</span></a></li>
         <li><a href="" ><span>Other page3</span></a></li>
		  <li><a href=""><span>Other page4</span></a></li>
		 <li><a href=""><span>Other page5</span></a></li>
         <li class='last'><a href="" ><span>Other page6</span></a></li>
      </ul>
   </li>
   
   <li class='active'><a href=""><span>Log out</span></a></li>
   
   
</ul>
</div>

 </nav>
 
</p>
 


</body>
</html>
