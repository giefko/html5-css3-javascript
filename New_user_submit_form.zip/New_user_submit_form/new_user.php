<?php session_start(); ?> 
<html>
<head>
  <meta charset="utf-8">
  
  
  <link rel="stylesheet" href="css/styleform.css">
  <meta http-equiv="content-type" content="text/html; charset=UTF-8">
</head>
<body>
 

<center>
  <section class="container">

    <div class="login">
      <h1>Registration Form</h1>  
	  <table align="center">
      <form action="new_user_process.php" method="POST" enctype="multipart/form-data" />
		<tr>
			<td align="right"><b>Name: </b><input type="text" name="name_user"></td>
		</tr>
		<tr>
			<td align="right"><b>Surename: </b><input type="text" name="surename_user"></td>
		</tr>
		<tr>
			<td align="right"><b>Username: </b><input type="text" name="user"></td>
		</tr>
		<tr>
			<td align="right"><b>Password: <input type="password" name="pass"/></td>
		</tr>
	  </table>
	  <p class="submit"><input type="submit" value="Submit"></p>
  
	  
	   
    </form>
	  
			
			
			</center>
		
	</body>
</html>
